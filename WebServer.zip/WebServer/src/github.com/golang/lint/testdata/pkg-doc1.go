// Test of missing package comment.

package foo // MATCH /should.*package comment.*unless/
