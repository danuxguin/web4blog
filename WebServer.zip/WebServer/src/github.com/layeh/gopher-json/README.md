# gopher-json [![GoDoc](https://godoc.org/github.com/layeh/gopher-json?status.svg)](https://godoc.org/github.com/layeh/gopher-json)

Package json is a simple JSON encoder/decoder for [gopher-lua](https://github.com/yuin/gopher-lua).

## License

Public domain.
