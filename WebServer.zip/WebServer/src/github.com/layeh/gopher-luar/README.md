# gopher-luar [![GoDoc](https://godoc.org/github.com/layeh/gopher-luar?status.svg)](https://godoc.org/github.com/layeh/gopher-luar)

custom type reflection for [gopher-lua](https://github.com/yuin/gopher-lua).

## License

MIT
